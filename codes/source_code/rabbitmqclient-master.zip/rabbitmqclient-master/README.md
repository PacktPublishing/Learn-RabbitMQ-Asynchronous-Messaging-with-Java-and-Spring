# rabbitmqclient
Experiments with RabbitTemplate

# rabbitmqlistener
Listener Configuration for RabbitMQ with Java and Spring
